import branding from '../images/branding.png'
import group from '../images/group.png'
import access from '../images/access.png'
import time from '../images/time.png'
import opening from '../images/opening.png'
import jobs from '../images/jobs.png'
import sla from '../images/sla.png'

import monitring from '../images/monitring.png'

import mobile from '../images/mobile.png'
import email from '../images/email.png'

import contractorPrio from '../images/contractorPrio.png'

import contractorCom from '../images/contractorCom.png'

import pc from '../images/pc.png'
import lt from '../images/LT.png'

import finance from '../images/help1.png'
import help from '../images/help1.png'

const settingData=[
    {
        Image:branding,

    },
    {
        Image:group,

    },
    {
        Image:access,

    },
    {
        Image:time,

    },
    {
        Image:opening,

    },
    {
        Image:jobs,

    },
    {
        Image:sla,

    },
    {
        Image:monitring,

    },
    {
        Image:mobile,

    },
    {
        Image:email,

    },
    {
        Image:contractorPrio,

    },
    {
        Image:contractorCom,

    },
    {
        Image:pc,

    },
    {
        Image:lt,
    },
    {
        Image:finance,

    },
    {
        Image:help,

    },

]

export default settingData;






