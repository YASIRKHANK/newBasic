
import imgOne from '../images/threeMark.png'
import imgTwo from '../images/threeDots.png'
import imgThree from '../images/danger.png'





const data=[
    {
        img:imgOne,
        text:'10,345',
        btn:'Active'

    },
    {
        img:imgTwo,
        text:'103',
        btn:'New/Pending'

    },
    {
        img:imgThree,
        text:'215',
        btn:'Suspendid'

    },
   
]

export default data;
