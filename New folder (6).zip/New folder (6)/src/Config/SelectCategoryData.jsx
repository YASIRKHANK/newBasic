import img1 from '../images/waterLeak.png'
import img4 from '../images/kit.png'
import img5 from '../images/whiteGood.png'
import img6 from '../images/car.png'
import img7 from '../images/jola.png'
import img8 from '../images/jola.png'
import img9 from '../images/jola.png'
import img10 from '../images/jola.png'
import img11 from '../images/jola.png'
import img12 from '../images/jola.png'
import img13 from '../images/jola.png'
import img14 from '../images/jola.png'
import img15 from '../images/jola.png'
import img16 from '../images/jola.png'




const SelectCategorydata=[
    {
        img:img1,
        text:'Water Leak'
    },
    {
        img:img1,
        text:'Water Leak'
    }, {
        img:img1,
        text:'Water Leak'
    },
    {
        img:img4,
        text:'Water Leak'
    },
    {
        img:img5,
        text:'Water Leak'
    },
    {
        img:img6,
        text:'Water Leak'
    },
    {
        img:img7,
        text:'Water Leak'
    },
    {
        img:img8,
        text:'Water Leak'
    },
    {
        img:img9,
        text:'Water Leak'
    },

    {
        img:img10,
        text:'Water Leak'
    },
    {
        img:img11,
        text:'Water Leak'
    },
    {
        img:img12,
        text:'Water Leak'
    },
    {
        img:img13,
        text:'Water Leak'
    },
    {
        img:img14,
        text:'Water Leak'
    },
    {
        img:img15,
        text:'Water Leak'
    },
    {
        img:img16,
        text:'Water Leak'
    },
    
]


export default SelectCategorydata;