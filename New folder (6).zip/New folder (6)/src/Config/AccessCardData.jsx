import access from '../images/access.png'
import access1 from '../images/access1.png'
import access2 from '../images/access2.png'
import access3 from '../images/access3.png'
import access4 from '../images/access4.png'



const accessData=[
    {
        img:access4,
        text:"Help Desk Role",
        number:'02',
    },
    {
        img:access,
        text:"Manager Role",
        number:'05',
    },
    {
        img:access1,
        text:"Finance Role",
        number:'05',
    },
    {
        img:access2,
        text:"Custom",
        number:'05',
    },
    {
        img:access3,
        text:"Grant",
        // number:'02',
    },

]


export default accessData;