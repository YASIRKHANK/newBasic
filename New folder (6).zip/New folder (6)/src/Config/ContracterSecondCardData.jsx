import Electrician from '../images/Electrician.png'
import plumbing from '../images/plumbing.png'
import tools from '../images/tools.png'
import key from '../images/key.png'
import gas from '../images/gas.png'
import pest from '../images/pest.png'
import other from '../images/other.png'
import drainage from '../images/drainag.png'
import gardner from '../images/gardner.png'






import check from '../images/check.png'
import prohibited from '../images/prohibited.png'
import filled from '../images/filled.png'

const SecondCardData=[
    {
        Image:Electrician,
        check:check,
        prohibited:prohibited,
        filled:filled,
        heading:'Electrician',
       zero:'0',
       active:'active',
       pending:'Pending',
       suspended:'Suspended',
       total:'Total Contractor',
       number:'40,886'


    },
    {
        Image:plumbing,
        check:check,
        prohibited:prohibited,
        filled:filled,
        heading:'Plumber',
        zero:'0',
       active:'active',
       pending:'Pending',
       suspended:'Suspended',
       total:'Total Contractor',
       number:'40,886'

    },
    {
        Image:tools,
        check:check,
        prohibited:prohibited,
        filled:filled,
        heading:'Handyman',
        zero:'0',
       active:'active',
       pending:'Pending',
       suspended:'Suspended',
       total:'Total Contractor',
       number:'40,886'

    },
    {
        Image:key,
        check:check,
        prohibited:prohibited,
        filled:filled,
        heading:'Key Holder',
        zero:'0',
       active:'active',
       pending:'Pending',
       suspended:'Suspended',
       total:'Total Contractor',
       number:'40,886'

    },
    {
        Image:gas,
        check:check,
        prohibited:prohibited,
        filled:filled,
        heading:'Gas & Heating',
        zero:'0',
       active:'active',
       pending:'Pending',
       suspended:'Suspended',
       total:'Total Contractor',
       number:'40,886'

    },
    {
        Image:drainage,
        check:check,
        prohibited:prohibited,
        filled:filled,
        heading:'Drainage',
        zero:'0',
       active:'active',
       pending:'Pending',
       suspended:'Suspended',
       total:'Total Contractor',
       number:'40,886'

    },
    {
        Image:pest,
        check:check,
        prohibited:prohibited,
        filled:filled,
        heading:'Pest control',
        zero:'0',
       active:'active',
       pending:'Pending',
       suspended:'Suspended',
       total:'Total Contractor',
       number:'40,886'
        


    },
    {
        Image:gardner,
        check:check,
        prohibited:prohibited,
        filled:filled,
        heading:'Gardener',
        zero:'0',
       active:'active',
       pending:'Pending',
       suspended:'Suspended',
       total:'Total Contractor',
       number:'40,886'

    },
    {
        Image:other,
        check:check,
        prohibited:prohibited,
        filled:filled,
        heading:'Other',
        zero:'0',
       active:'active',
       pending:'Pending',
       suspended:'Suspended',
       total:'Total Contractor',
       number:'40,886'

    },
]

export default SecondCardData;